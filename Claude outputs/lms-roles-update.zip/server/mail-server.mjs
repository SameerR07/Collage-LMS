/* Stand-alone mail server — only needed when the built app is hosted somewhere
   (during `npm run dev` the same API already runs inside Vite).

     npm run mail-server        start on 127.0.0.1:8787
     npm run mail-check         test the email + password in server/.env and exit

   Put it behind the same domain as the app (e.g. a reverse proxy for /api/mail),
   and set MAIL_API_TOKEN (and VITE_MAIL_API_TOKEN for the app) if it is reachable from outside. */
import http from 'node:http'
import { fileURLToPath } from 'node:url'
import { createMailApi, parseEnv } from './mailApi.mjs'
import { existsSync, readFileSync } from 'node:fs'

const envFile = fileURLToPath(new URL('./.env', import.meta.url))
const fileEnv = existsSync(envFile) ? parseEnv(readFileSync(envFile, 'utf8')) : {}
const api = createMailApi({ envFile })

if (process.argv.includes('--check')) {
  const result = await api.verify()
  console.log(result.ok ? `✓ Email works: ${result.from} via ${result.host}` : `✗ ${result.error}`)
  api.close()
  process.exit(result.ok ? 0 : 1)
}

const host = fileEnv.MAIL_SERVER_HOST || process.env.MAIL_SERVER_HOST || '127.0.0.1'
const port = Number(fileEnv.MAIL_SERVER_PORT || process.env.MAIL_SERVER_PORT || 8787)
http.createServer((req, res) => api.handle(req, res)).listen(port, host, () => {
  const state = api.status()
  console.log(`GJIMT mail server on http://${host}:${port}/api/mail — ${state.configured ? `sending as ${state.from}` : 'waiting for SMTP_USER / SMTP_PASS in server/.env'}`)
})
