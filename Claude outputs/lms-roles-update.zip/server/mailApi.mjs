/* =========================================================
   Mail API — sends placement drive emails over SMTP (Nodemailer).

   Runs inside `npm run dev` / `npm run preview` (see vite.config.js),
   or on its own with `npm run mail-server` when the app is hosted.

   Settings come from server/.env (never sent to the browser):
     SMTP_USER / SMTP_PASS   the sending email and its password
                             (Gmail: a 16-letter App Password)
     SMTP_HOST / SMTP_PORT   default smtp.gmail.com : 465
   The file is re-read automatically when it changes — no restart.

   Endpoints
     GET  /api/mail/status   { configured, from, host }
     POST /api/mail/drive    { drive, recipients[], update } → { results[] }
========================================================= */
import { existsSync, readFileSync, statSync } from 'node:fs'
import nodemailer from 'nodemailer'
import { buildDriveEmail, parseCourses } from '../src/lib/driveEmail.js'

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const MAX_RECIPIENTS_PER_REQUEST = 50
const MAX_BODY_BYTES = 256 * 1024
const DRIVE_KEYS = ['company', 'role', 'ctc', 'locations', 'driveDate', 'reportingTime', 'venue', 'roundsCount', 'round1', 'round2', 'round3', 'eligible', 'requirements', 'summary']

/** Minimal .env reader: KEY=value lines, # comments, optional quotes. */
export function parseEnv(text) {
  const values = {}
  String(text).split(/\r?\n/).forEach((line) => {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/)
    if (!match) return
    let value = match[2].trim()
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1)
    else value = value.replace(/\s+#.*$/, '')
    values[match[1]] = value
  })
  return values
}

const maskEmail = (email) => {
  const [user, domain] = String(email).split('@')
  if (!domain) return ''
  return `${user.slice(0, 2)}${'•'.repeat(Math.min(6, Math.max(2, user.length - 2)))}@${domain}`
}

export function createMailApi({ envFile, env = process.env, log = console } = {}) {
  let cache = { mtime: -1, settings: null, transporter: null }

  const settings = () => {
    let fileValues = {}
    let mtime = 0
    if (envFile && existsSync(envFile)) {
      mtime = statSync(envFile).mtimeMs
      if (mtime === cache.mtime && cache.settings) return cache.settings
      fileValues = parseEnv(readFileSync(envFile, 'utf8'))
    } else if (cache.settings && cache.mtime === 0) return cache.settings
    const value = (key, fallback = '') => String(fileValues[key] ?? env[key] ?? fallback).trim()
    const port = Number(value('SMTP_PORT', '465')) || 465
    const next = {
      host: value('SMTP_HOST', 'smtp.gmail.com'),
      port,
      secure: value('SMTP_SECURE') ? value('SMTP_SECURE').toLowerCase() === 'true' : port === 465,
      user: value('SMTP_USER'),
      pass: value('SMTP_PASS').replace(/\s+/g, ''), // Gmail shows App Passwords in groups of four
      fromName: value('MAIL_FROM_NAME', 'GJIMT Placement Cell'),
      replyTo: value('MAIL_REPLY_TO'),
      token: value('MAIL_API_TOKEN'),
      delayMs: Number(value('MAIL_DELAY_MS', '300')) || 0,
    }
    next.configured = Boolean(next.user && next.pass)
    if (cache.transporter) cache.transporter.close()
    cache = {
      mtime,
      settings: next,
      transporter: next.configured
        ? nodemailer.createTransport({ host: next.host, port: next.port, secure: next.secure, auth: { user: next.user, pass: next.pass }, pool: true, maxConnections: 2, maxMessages: 100 })
        : null,
    }
    return next
  }

  const status = () => {
    const current = settings()
    return { ok: true, configured: current.configured, from: current.configured ? maskEmail(current.user) : '', host: current.host }
  }

  /** Validate the drive and recipients the app sent; returns a clean copy or throws. */
  const cleanRequest = (body) => {
    const drive = {}
    DRIVE_KEYS.forEach((key) => { drive[key] = String(body?.drive?.[key] ?? '').slice(0, 4000) })
    if (!drive.company || !drive.role || !drive.driveDate) throw Object.assign(new Error('The drive needs a company, job role and date.'), { status: 400 })
    if (!parseCourses(drive.eligible).length) throw Object.assign(new Error('The drive has no eligible course.'), { status: 400 })
    const list = Array.isArray(body?.recipients) ? body.recipients : []
    if (!list.length) throw Object.assign(new Error('No recipients.'), { status: 400 })
    if (list.length > MAX_RECIPIENTS_PER_REQUEST) throw Object.assign(new Error(`Send at most ${MAX_RECIPIENTS_PER_REQUEST} emails per request.`), { status: 413 })
    const recipients = list.map((item) => ({
      email: String(item?.email ?? '').trim().toLowerCase(),
      name: String(item?.name ?? '').slice(0, 120),
      course: String(item?.course ?? '').slice(0, 40),
    }))
    return { drive, recipients, update: Boolean(body?.update) }
  }

  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

  /** Sends one personal email per student. Returns [{ email, ok, error }]. */
  const sendDrive = async (body) => {
    const current = settings()
    if (!current.configured) throw Object.assign(new Error('Email is not set up yet. Add SMTP_USER and SMTP_PASS to server/.env.'), { status: 503, code: 'not-configured' })
    const { drive, recipients, update } = cleanRequest(body)
    const results = []
    for (const [index, student] of recipients.entries()) {
      if (!EMAIL.test(student.email)) { results.push({ email: student.email, ok: false, error: 'Invalid email address' }); continue }
      const message = buildDriveEmail(drive, student, { update, senderName: current.fromName })
      try {
        const info = await cache.transporter.sendMail({
          from: { name: current.fromName, address: current.user },
          to: student.name ? { name: student.name, address: student.email } : student.email,
          replyTo: current.replyTo || undefined,
          subject: message.subject,
          text: message.text,
          html: message.html,
        })
        const rejected = (info.rejected || []).length > 0
        results.push({ email: student.email, ok: !rejected, error: rejected ? 'Rejected by the mail server' : '' })
      } catch (error) {
        results.push({ email: student.email, ok: false, error: friendlySmtpError(error) })
        if (error?.code === 'EAUTH') { // wrong password — no point trying the rest of this batch
          recipients.slice(index + 1).forEach((rest) => results.push({ email: rest.email, ok: false, error: friendlySmtpError(error) }))
          break
        }
      }
      if (current.delayMs && index < recipients.length - 1) await wait(current.delayMs)
    }
    const sent = results.filter((result) => result.ok).length
    log.info?.(`[mail] ${drive.company} — ${sent}/${results.length} sent`)
    return { results }
  }

  const readBody = (req) => new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > MAX_BODY_BYTES) { reject(Object.assign(new Error('Request too large'), { status: 413 })); req.destroy() } else chunks.push(chunk)
    })
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')) } catch { reject(Object.assign(new Error('Invalid JSON'), { status: 400 })) } })
    req.on('error', reject)
  })

  const send = (res, status, payload) => {
    res.statusCode = status
    res.setHeader('Content-Type', 'application/json; charset=utf-8')
    res.setHeader('Cache-Control', 'no-store')
    res.end(JSON.stringify(payload))
  }

  /** Connect/Node style handler: handles /api/mail/* and passes everything else on. */
  const handle = async (req, res, next = () => send(res, 404, { error: 'Not found' })) => {
    const path = String(req.url || '').split('?')[0]
    if (!path.startsWith('/api/mail/')) return next()
    try {
      const current = settings()
      if (current.token && req.headers['x-mail-token'] !== current.token) return send(res, 401, { error: 'Not allowed' })
      if (path === '/api/mail/status' && req.method === 'GET') return send(res, 200, status())
      if (path === '/api/mail/drive' && req.method === 'POST') {
        if (!String(req.headers['content-type'] || '').includes('application/json')) return send(res, 415, { error: 'Send JSON' })
        return send(res, 200, await sendDrive(await readBody(req)))
      }
      return send(res, 404, { error: 'Not found' })
    } catch (error) {
      return send(res, error.status || 500, { error: error.message || 'Mail error', code: error.code || '' })
    }
  }

  const verify = async () => {
    const current = settings()
    if (!current.configured) return { ok: false, error: 'SMTP_USER and SMTP_PASS are not set in server/.env' }
    try { await cache.transporter.verify(); return { ok: true, from: current.user, host: current.host } } catch (error) { return { ok: false, error: friendlySmtpError(error) } }
  }

  return { handle, status, verify, close: () => cache.transporter?.close() }
}

export function friendlySmtpError(error) {
  const code = error?.code || ''
  const response = String(error?.response || error?.message || '')
  if (code === 'EAUTH' || /535|534|Username and Password not accepted/i.test(response)) {
    return 'The email or password was not accepted. For Gmail, use a 16-letter App Password (Google Account → Security → App passwords).'
  }
  if (code === 'ECONNECTION' || code === 'ETIMEDOUT' || code === 'ESOCKET' || code === 'EDNS') return 'Could not reach the mail server. Check the internet connection and SMTP_HOST / SMTP_PORT.'
  if (/550|553|invalid|does not exist|no such user/i.test(response)) return 'This address was refused by the mail server.'
  if (/daily|limit|quota|421|452/i.test(response)) return 'The mail server’s sending limit was reached. Try again later.'
  return response.split('\n')[0].slice(0, 200) || 'Email could not be sent.'
}
