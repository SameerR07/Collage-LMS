import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  AccessTimeRounded, BusinessRounded, CampaignRounded, CheckRounded, EventRounded, GroupsRounded, LayersRounded,
  MailOutlineRounded, MarkEmailReadRounded, PlaceRounded, SaveRounded, SchoolRounded, VisibilityRounded,
} from '@mui/icons-material'
import AppShell from '../components/AppShell'
import PageBanner from '../components/PageBanner'
import Modal from '../components/Modal'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { addRecord, listRecords, updateRecord } from '../lib/dataStore'
import {
  DEFAULT_LEAVE_OUT, DRIVE_COURSES, LEAVE_OUT_OPTIONS, buildDriveEmail, driveProblems, joinList, parseCourses, selectRecipients, splitList,
} from '../lib/driveEmail'
import { DRIVES, emailSummaryText, getDrive, todayISO } from '../lib/drives'
import { getMailStatus } from '../lib/mailClient'

const EMPTY = {
  company: '', role: '', ctc: '', locations: '', driveDate: '', reportingTime: '', venue: '',
  roundsCount: '3', round1: '', round2: '', round3: '', eligible: [], requirements: '', summary: '', status: 'Open',
  leaveOut: DEFAULT_LEAVE_OUT, batches: [],
}
const ORDINAL = ['1st', '2nd', '3rd']
const ROUND_HINT = ['e.g. Aptitude test', 'e.g. Technical interview', 'e.g. HR interview']

const fromRecord = (drive) => ({
  ...EMPTY,
  ...Object.fromEntries(Object.keys(EMPTY).map((key) => [key, drive[key] ?? EMPTY[key]])),
  roundsCount: String(drive.roundsCount || '1'),
  eligible: parseCourses(drive.eligible),
  leaveOut: drive.leaveOut !== undefined ? splitList(drive.leaveOut) : DEFAULT_LEAVE_OUT,
  batches: splitList(drive.batches),
})

function Field({ id, label, hint, error, wide, children }) {
  return (
    <div className={`drive-field ${wide ? 'wide' : ''} ${error ? 'has-error' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {error ? <span className="field-hint error" role="alert">{error}</span> : hint ? <span className="field-hint">{hint}</span> : null}
    </div>
  )
}

export default function DriveForm() {
  const { id } = useParams()
  const editing = Boolean(id)
  const navigate = useNavigate()
  const { user } = useAuth()
  const { push } = useToast()
  const [form, setForm] = useState(EMPTY)
  const [original, setOriginal] = useState(null)
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [touched, setTouched] = useState(false)
  const [saving, setSaving] = useState(false)
  const [emailUpdate, setEmailUpdate] = useState(false)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [mail, setMail] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    let alive = true
    Promise.all([listRecords('students'), editing ? getDrive(id) : Promise.resolve(null), getMailStatus()])
      .then(([studentRows, drive, mailStatus]) => {
        if (!alive) return
        setStudents(studentRows)
        setMail(mailStatus)
        if (editing) {
          if (!drive) { push('That drive no longer exists.', 'error'); navigate('/drives', { replace: true }); return }
          setOriginal(drive); setForm(fromRecord(drive))
        }
      })
      .catch(() => push('Could not load the student list.', 'error'))
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [editing, id, navigate, push])

  const set = (key) => (event) => { setForm((current) => ({ ...current, [key]: event?.target ? event.target.value : event })); setError('') }
  const toggle = (key, value) => setForm((current) => {
    const list = current[key]
    return { ...current, [key]: list.includes(value) ? list.filter((item) => item !== value) : [...list, value] }
  })

  const record = useMemo(() => ({ ...form, eligible: form.eligible.join(', '), locations: joinList(form.locations) }), [form])
  const problems = driveProblems(record)
  const show = (key) => (touched ? problems[key] : '')

  const courseCounts = useMemo(() => Object.fromEntries(DRIVE_COURSES.map((course) => [course, selectRecipients(students, { courses: [course], leaveOut: [] }).inCourses])), [students])
  const batchOptions = useMemo(() => {
    const wanted = new Set(form.eligible)
    return [...new Set(students.filter((student) => parseCourses(student.course).some((course) => wanted.has(course))).map((student) => String(student.batch || '').trim()).filter(Boolean))].sort()
  }, [students, form.eligible])
  const audience = useMemo(() => selectRecipients(students, { courses: form.eligible, leaveOut: form.leaveOut, batches: form.batches.filter((batch) => batchOptions.includes(batch)) }), [students, form.eligible, form.leaveOut, form.batches, batchOptions])
  const recipientCount = audience.recipients.length
  const leftOut = Object.entries(audience.skipped.byStatus)

  const preview = useMemo(() => buildDriveEmail(record, audience.recipients[0] || { name: 'Student', course: form.eligible[0] }, { update: editing }), [record, audience.recipients, form.eligible, editing])

  const save = async (sendEmail) => {
    setTouched(true)
    setError('')
    if (Object.keys(problems).length) {
      setError('Please fill in the highlighted details.')
      requestAnimationFrame(() => document.querySelector('.drive-field.has-error input, .drive-field.has-error textarea, .drive-field.has-error .course-picks button')?.focus())
      return
    }
    if (sendEmail && !recipientCount) { setError('No students match the ticked courses, so there is nobody to email. Check the courses or the “Don’t email” choices.'); return }
    if (sendEmail && !window.confirm(`Email the ${record.company} drive details to ${recipientCount} student${recipientCount === 1 ? '' : 's'} now?`)) return
    setSaving(true)
    const count = Number(form.roundsCount)
    const now = new Date().toISOString()
    const payload = {
      company: record.company.trim(), role: record.role.trim(), ctc: record.ctc.trim(), locations: record.locations,
      driveDate: record.driveDate, reportingTime: record.reportingTime, venue: record.venue.trim(),
      roundsCount: String(count), round1: record.round1.trim(), round2: count >= 2 ? record.round2.trim() : '', round3: count >= 3 ? record.round3.trim() : '',
      eligible: record.eligible, requirements: record.requirements.trim(), summary: record.summary.trim(),
      status: record.status || 'Open', leaveOut: form.leaveOut.join(', '), batches: form.batches.filter((batch) => batchOptions.includes(batch)).join(', '),
      updatedBy: user?.email || '', updatedAt: now,
      ...(editing ? {} : { createdBy: user?.email || '', postedBy: user?.displayName || '' }),
    }
    if (sendEmail) {
      const log = audience.recipients.map(({ name, email, course }) => ({ name, email, course, status: 'queued' }))
      Object.assign(payload, {
        emailLog: log, emailKind: editing ? 'update' : 'new', emailRequestedAt: now, emailSummary: emailSummaryText(log),
        ...(original?.emailLog?.length ? { emailHistory: [...(original.emailHistory || []), { kind: original.emailKind || 'new', at: original.emailUpdatedAt || original.emailRequestedAt || '', summary: original.emailSummary || '' }] } : {}),
      })
    }
    try {
      const saved = editing ? (await updateRecord(DRIVES, id, payload), { id }) : await addRecord(DRIVES, payload)
      push(sendEmail ? `Drive saved — emailing ${recipientCount} student${recipientCount === 1 ? '' : 's'}…` : 'Drive saved.')
      navigate(`/drives/${saved.id}`, { state: { send: sendEmail } })
    } catch (err) {
      setError(err?.message || 'The drive could not be saved.')
    } finally { setSaving(false) }
  }

  const title = editing ? `Edit ${original?.company || 'drive'}` : 'New placement drive'

  return <AppShell title={editing ? 'Edit drive' : 'New drive'} subtitle="Placement Drives"><div className="page-stack drive-form-page">
    <PageBanner
      icon={CampaignRounded}
      eyebrow="Placement Drive desk"
      title={title}
      description={editing ? 'Change any detail. You can email the updated details to the students again.' : 'Fill in the drive details, tick the eligible courses, and every matching student gets the full details by email.'}
      back={{ to: editing ? `/drives/${id}` : '/drives', label: editing ? 'Back to drive' : 'All drives' }}
    />

    {/* Enter in a field never sends emails — only the buttons do */}
    <form className="drive-layout" onSubmit={(event) => event.preventDefault()} noValidate aria-busy={loading}>
      <div className="drive-sections">
        <section className="surface-card drive-card">
          <div className="surface-head"><div><span>Step 1</span><h3>Company &amp; job</h3></div><BusinessRounded /></div>
          <div className="drive-grid">
            <Field id="d-company" label="Company *" error={show('company')}><input id="d-company" value={form.company} onChange={set('company')} placeholder="e.g. TechNova Solutions" autoComplete="organization" /></Field>
            <Field id="d-role" label="Job role *" error={show('role')}><input id="d-role" value={form.role} onChange={set('role')} placeholder="e.g. Graduate Engineer Trainee" /></Field>
            <Field id="d-ctc" label="Package *" error={show('ctc')} hint="CTC or stipend, as you want students to see it"><input id="d-ctc" value={form.ctc} onChange={set('ctc')} placeholder="e.g. ₹4.5 LPA" /></Field>
            <Field id="d-locations" label="Job location(s) *" error={show('locations')} hint="Separate places with commas"><input id="d-locations" value={form.locations} onChange={set('locations')} placeholder="e.g. Mohali, Chandigarh, Remote" /></Field>
          </div>
        </section>

        <section className="surface-card drive-card">
          <div className="surface-head"><div><span>Step 2</span><h3>Drive day</h3></div><EventRounded /></div>
          <div className="drive-grid three">
            <Field id="d-date" label="Date of drive *" error={show('driveDate')}><input id="d-date" type="date" value={form.driveDate} min={editing ? undefined : todayISO()} onChange={set('driveDate')} /></Field>
            <Field id="d-time" label="Reporting time *" error={show('reportingTime')}><input id="d-time" type="time" value={form.reportingTime} onChange={set('reportingTime')} /></Field>
            <Field id="d-status" label="Status"><select id="d-status" value={form.status} onChange={set('status')}><option>Open</option><option>Scheduled</option><option>Closed</option></select></Field>
            <Field id="d-venue" label="Venue *" error={show('venue')} wide><input id="d-venue" value={form.venue} onChange={set('venue')} placeholder="e.g. Seminar Hall, Block B, GJIMT Mohali" /></Field>
          </div>
        </section>

        <section className="surface-card drive-card">
          <div className="surface-head"><div><span>Step 3</span><h3>Selection rounds</h3></div><LayersRounded /></div>
          <div className="rounds-picker" role="radiogroup" aria-label="Number of rounds">
            <span>Number of rounds</span>
            {['1', '2', '3'].map((count) => <button key={count} type="button" role="radio" aria-checked={form.roundsCount === count} className={form.roundsCount === count ? 'active' : ''} onClick={() => set('roundsCount')(count)}>{count} {count === '1' ? 'round' : 'rounds'}</button>)}
          </div>
          <div className="drive-grid three">
            {Array.from({ length: Number(form.roundsCount) }, (_, index) => {
              const key = `round${index + 1}`
              return <Field key={key} id={`d-${key}`} label={`${ORDINAL[index]} round *`} error={show(key)}><input id={`d-${key}`} value={form[key]} onChange={set(key)} placeholder={ROUND_HINT[index]} /></Field>
            })}
          </div>
        </section>

        <section className="surface-card drive-card">
          <div className="surface-head"><div><span>Step 4</span><h3>Who can apply</h3></div><SchoolRounded /></div>
          <div className={`drive-field wide ${show('eligible') ? 'has-error' : ''}`}>
            <span className="drive-label" id="courses-label">Job valid for *</span>
            <div className="course-picks" role="group" aria-labelledby="courses-label">
              {DRIVE_COURSES.map((course) => {
                const on = form.eligible.includes(course)
                return <button key={course} type="button" role="checkbox" aria-checked={on} className={`course-pick ${on ? 'on' : ''}`} onClick={() => toggle('eligible', course)}>
                  <i aria-hidden="true">{on && <CheckRounded />}</i><strong>{course}</strong><small>{loading ? '…' : `${courseCounts[course]} student${courseCounts[course] === 1 ? '' : 's'}`}</small>
                </button>
              })}
            </div>
            {show('eligible') && <span className="field-hint error" role="alert">{problems.eligible}</span>}
          </div>
          {batchOptions.length > 1 && <div className="drive-field wide">
            <span className="drive-label" id="batch-label">Batches <em>(optional — leave all unticked for every batch)</em></span>
            <div className="chip-picks" role="group" aria-labelledby="batch-label">
              {batchOptions.map((batch) => <button key={batch} type="button" role="checkbox" aria-checked={form.batches.includes(batch)} className={`chip-pick ${form.batches.includes(batch) ? 'on' : ''}`} onClick={() => toggle('batches', batch)}>{batch}</button>)}
            </div>
          </div>}
          <div className="drive-field wide">
            <span className="drive-label" id="leave-label">Don’t email students who are</span>
            <div className="chip-picks" role="group" aria-labelledby="leave-label">
              {LEAVE_OUT_OPTIONS.map((option) => <button key={option.status} type="button" role="checkbox" aria-checked={form.leaveOut.includes(option.status)} className={`chip-pick ${form.leaveOut.includes(option.status) ? 'on' : ''}`} onClick={() => toggle('leaveOut', option.status)}>{option.label}</button>)}
            </div>
          </div>
        </section>

        <section className="surface-card drive-card">
          <div className="surface-head"><div><span>Step 5</span><h3>Job details</h3></div><GroupsRounded /></div>
          <div className="drive-grid">
            <Field id="d-req" label="Requirements for the job role *" error={show('requirements')} hint="Skills, marks criteria, documents to bring — one per line is fine" wide><textarea id="d-req" rows={5} value={form.requirements} onChange={set('requirements')} placeholder={'e.g.\n60% throughout 10th, 12th and graduation\nGood communication skills\nBring 2 copies of your resume'} /></Field>
            <Field id="d-summary" label="Brief summary of the job *" error={show('summary')} hint="This appears in the email under “About the job”" wide><textarea id="d-summary" rows={5} value={form.summary} onChange={set('summary')} placeholder="What the job involves, training period, growth, bond (if any)…" /></Field>
          </div>
        </section>
      </div>

      <aside className="drive-aside">
        <section className="surface-card audience-card" aria-live="polite">
          <div className="surface-head"><div><span>Email goes to</span><h3><strong className="audience-total" data-testid="recipient-count">{loading ? '…' : recipientCount}</strong> student{recipientCount === 1 ? '' : 's'}</h3></div><MailOutlineRounded /></div>
          {!form.eligible.length && <p className="audience-note">Tick the courses this job is valid for.</p>}
          {form.eligible.length > 0 && <ul className="audience-list">
            {form.eligible.map((course) => <li key={course}><span>{course}</span><strong>{audience.byCourse[course] || 0}</strong></li>)}
          </ul>}
          {(leftOut.length > 0 || audience.skipped.noEmail > 0 || audience.skipped.duplicate > 0 || audience.skipped.otherBatch > 0) && <div className="audience-skipped">
            <span>Not emailed</span>
            <ul>
              {leftOut.map(([status, count]) => <li key={status}>{count} {status.toLowerCase()}</li>)}
              {audience.skipped.otherBatch > 0 && <li>{audience.skipped.otherBatch} in other batches</li>}
              {audience.skipped.noEmail > 0 && <li>{audience.skipped.noEmail} with no valid email ID</li>}
              {audience.skipped.duplicate > 0 && <li>{audience.skipped.duplicate} repeated email</li>}
            </ul>
          </div>}
          <button type="button" className="soft-button full" onClick={() => setPreviewOpen(true)} disabled={!form.company && !form.role}><VisibilityRounded /> Preview the email</button>
          <p className={`mail-state ${mail?.configured ? 'ready' : 'waiting'}`}><i aria-hidden="true" />{mail === null ? 'Checking the email service…' : mail.configured ? `Email ready — sends as ${mail.from}` : mail.reachable ? 'Email not set up yet — emails will wait in the queue' : 'Email service not running here — emails will wait in the queue'}</p>
        </section>

        <section className="surface-card save-card">
          {error && <div className="form-error" role="alert">{error}</div>}
          {editing && <label className="check-row"><input type="checkbox" checked={emailUpdate} onChange={(event) => setEmailUpdate(event.target.checked)} /><span>Email the updated details to {recipientCount} student{recipientCount === 1 ? '' : 's'}</span></label>}
          {editing
            ? <button type="button" className="primary-button full" disabled={saving || loading} onClick={() => save(emailUpdate)}>{emailUpdate ? <MarkEmailReadRounded /> : <SaveRounded />} {saving ? 'Saving…' : emailUpdate ? 'Save & email update' : 'Save changes'}</button>
            : <>
              <button type="button" className="primary-button full" disabled={saving || loading} onClick={() => save(true)}><MarkEmailReadRounded /> {saving ? 'Saving…' : `Save & email ${recipientCount} student${recipientCount === 1 ? '' : 's'}`}</button>
              <button type="button" className="soft-button full" disabled={saving || loading} onClick={() => save(false)}><SaveRounded /> Save without emailing</button>
            </>}
          <p className="save-note"><AccessTimeRounded /> <span>Saved drives appear in the Placement Drives list{editing ? '' : ', where you can email students later'}.</span></p>
          <p className="save-note"><PlaceRounded /> <span>Students get one personal email each, with all the details above.</span></p>
        </section>
      </aside>
    </form>

    <Modal open={previewOpen} onClose={() => setPreviewOpen(false)} eyebrow="Email preview" title="What students receive" description={`Subject: ${preview.subject}`} width="760px">
      <iframe className="email-preview" title="Email preview" sandbox="" srcDoc={preview.html} />
    </Modal>
  </div></AppShell>
}
