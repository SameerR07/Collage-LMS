import { useEffect, useState } from 'react'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import {
  AdminPanelSettingsRounded, ArrowBackRounded, ArrowForwardRounded, AutoAwesomeRounded, BadgeOutlined, BusinessCenterRounded,
  CheckCircleRounded, ChevronRightRounded, EmailOutlined, HourglassTopRounded, LockRounded, SchoolRounded, ShieldRounded,
  VisibilityOffRounded, VisibilityRounded,
} from '@mui/icons-material'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { passwordStrength, signUpProblems } from '../lib/authHelpers'
import { ROLE_INFO, canAccess, homeFor, roleLabel } from '../lib/roles'
import LoginRail from '../components/LoginRail'

const PORTALS = [
  { role: 'admin', icon: AdminPanelSettingsRounded, title: 'Login as Admin' },
  { role: 'placement', icon: BusinessCenterRounded, title: 'Login as Placement Cell' },
  { role: 'student', icon: SchoolRounded, title: 'Login as Student' },
]
const PORTAL_ICON = Object.fromEntries(PORTALS.map((portal) => [portal.role, portal.icon]))

function PasswordInput({ id, value, onChange, show, onToggle, placeholder, autoComplete, invalid }) {
  return (
    <div className={`input-shell ${invalid ? 'invalid' : ''}`}>
      <LockRounded />
      <input id={id} type={show ? 'text' : 'password'} autoComplete={autoComplete} placeholder={placeholder} value={value} onChange={onChange} aria-invalid={invalid || undefined} required />
      <button type="button" className="input-action" onClick={onToggle} aria-label={show ? 'Hide password' : 'Show password'}>{show ? <VisibilityOffRounded /> : <VisibilityRounded />}</button>
    </div>
  )
}

export default function Login() {
  const navigate = useNavigate()
  const location = useLocation()
  const [params, setParams] = useSearchParams()
  const { user, signInEmail, signUpEmail, signInGoogle, resetPassword, isFirebaseConfigured } = useAuth()
  const { push } = useToast()
  const portal = ROLE_INFO[params.get('as')] ? params.get('as') : null
  const [mode, setMode] = useState('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [remember, setRemember] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [touched, setTouched] = useState(false)
  const [requested, setRequested] = useState(null) // account just created, waiting for approval

  useEffect(() => {
    if (user && canAccess(user.role, homeFor(user.role))) navigate(homeFor(user.role), { replace: true })
  }, [user, navigate])

  const resetForm = () => { setError(''); setTouched(false); setShowPassword(false); setPassword(''); setConfirm(''); setRequested(null) }
  const choosePortal = (role) => { resetForm(); setMode('login'); setParams(role ? { as: role } : {}) }
  const switchMode = (next) => { resetForm(); setMode(next) }

  const goHome = (signedIn) => {
    const from = location.state?.from
    navigate(from && canAccess(signedIn.role, from) ? from : homeFor(signedIn.role), { replace: true })
  }

  const submit = async (event) => {
    event.preventDefault()
    setError('')
    setBusy(true)
    try {
      const signedIn = await signInEmail(email, password, remember, portal)
      push(`Welcome back — your ${roleLabel(signedIn.role)} workspace is ready.`)
      goHome(signedIn)
    } catch (err) {
      setError(err?.message || 'Login failed. Please check your details.')
    } finally { setBusy(false) }
  }

  const problems = signUpProblems({ name, email, password, confirm })
  const strength = passwordStrength(password)

  const signUp = async (event) => {
    event.preventDefault()
    setTouched(true)
    setError('')
    if (Object.keys(problems).length) return
    setBusy(true)
    try {
      const { account, verificationSent } = await signUpEmail({ name, email, password, confirm, role: portal })
      setRequested({ ...account, verificationSent })
      setPassword(''); setConfirm('')
    } catch (err) {
      setError(err?.message || 'Your account could not be created.')
    } finally { setBusy(false) }
  }

  const googleLogin = async () => {
    setError('')
    setBusy(true)
    try { const signedIn = await signInGoogle(remember, portal); if (signedIn) goHome(signedIn) }
    catch (err) { setError(err?.message || 'Google sign-in failed.') }
    finally { setBusy(false) }
  }

  const forgot = async () => {
    setError('')
    if (!email.trim()) { setError('Enter your email first, then use Forgot password.'); return }
    setBusy(true)
    try { await resetPassword(email); push('Password reset email sent. Check your inbox.') }
    catch (err) { setError(err?.message || 'Password reset could not be sent.') }
    finally { setBusy(false) }
  }

  const show = (field) => touched && problems[field]
  const info = portal ? ROLE_INFO[portal] : null
  const PortalIcon = portal ? PORTAL_ICON[portal] : null
  const canSignUp = Boolean(info?.signUp)

  const heading = !portal
    ? { eyebrow: 'GJIMT Placement LMS', title: 'Choose your portal', text: 'Sign in to the area that matches your role.' }
    : info.comingSoon
      ? { eyebrow: `${info.label} portal`, title: 'Coming soon', text: 'Student login is being prepared.' }
      : requested
        ? { eyebrow: `${info.label} portal`, title: 'Request sent', text: 'Your account is waiting for the Admin’s approval.' }
        : mode === 'signup'
          ? { eyebrow: `${info.label} portal`, title: 'Create your account', text: 'The Admin approves new Placement Cell accounts before first sign-in.' }
          : { eyebrow: `${info.label} portal`, title: 'Welcome back', text: `Sign in to the ${info.label} workspace.` }

  return (
    <div className="login-page">
      <div className="login-layout">
        <div className="login-card-shell">
          <section className="login-showcase" aria-label="About the GJIMT Placement LMS">
            <div className="login-brand-row">
              <span className="logo-plate"><img src="/gjimt-brand.png" alt="GJIMT — NAAC accredited" className="login-brand" /></span>
              <span className="brand-pill"><ShieldRounded /> Verified campus portal</span>
            </div>
            <div className="showcase-copy">
              <span className="showcase-kicker"><AutoAwesomeRounded /> Built for your placement journey</span>
              <h1>Learn. Prepare.<br /><em>Get placed.</em></h1>
              <p>One refined workspace for internships, placement drives, student records, industry connect and career-readiness activities.</p>
            </div>
            <div className="showcase-highlights">
              <div><strong>01</strong><span>Centralised student data</span></div>
              <div><strong>02</strong><span>Faster placement coordination</span></div>
              <div><strong>03</strong><span>Role-based secure sign-in</span></div>
            </div>
            <div className="showcase-footer"><span>Gian Jyoti Institute of Management &amp; Technology</span><span className="motto">Aspire · Achieve · Ascend</span></div>
          </section>

          <section className="login-form-panel">
            {portal && <div className="portal-bar">
              <button type="button" className="portal-back" onClick={() => choosePortal(null)}><ArrowBackRounded /> All portals</button>
              <span className={`portal-chip ${portal}`}><PortalIcon /> {info.label}</span>
            </div>}
            <div className="login-head">
              <span className="login-eyebrow">{heading.eyebrow}</span>
              <h2>{heading.title}</h2>
              <p>{heading.text}</p>
            </div>

            {!portal && <div className="portal-list">
              {PORTALS.map(({ role, icon: Icon, title }) => (
                <button key={role} type="button" className={`portal-option ${role}`} onClick={() => choosePortal(role)}>
                  <span className="portal-icon"><Icon /></span>
                  <span className="portal-text"><strong>{title}</strong><small>{ROLE_INFO[role].blurb}</small></span>
                  {ROLE_INFO[role].comingSoon ? <em className="soon-badge">Coming soon</em> : <ChevronRightRounded className="portal-arrow" />}
                </button>
              ))}
            </div>}

            {portal && info.comingSoon && <div className="coming-soon-panel">
              <span className="coming-soon-icon"><SchoolRounded /></span>
              <p>Students will soon be able to sign in here to see placement drives for their course. Until then, drive details reach you by email from the Placement Cell.</p>
              <button type="button" className="soft-button" onClick={() => choosePortal(null)}><ArrowBackRounded /> Back to all portals</button>
            </div>}

            {portal && !info.comingSoon && requested && <div className="request-panel" role="status">
              <span className="request-icon"><HourglassTopRounded /></span>
              <p><strong>{requested.name}</strong>, your Placement Cell account (<span>{requested.email}</span>) has been created.</p>
              <p>The Admin needs to approve it before you can sign in.{requested.verificationSent ? ' We also sent a link to verify your email.' : ''}</p>
              <button type="button" className="primary-login" onClick={() => { setRequested(null); setMode('login') }}><span>Back to sign in</span><ArrowForwardRounded /></button>
            </div>}

            {portal && !info.comingSoon && !requested && canSignUp && <div className="auth-tabs" role="tablist" aria-label="Sign-in options">
              <button role="tab" aria-selected={mode === 'login'} className={mode === 'login' ? 'active' : ''} onClick={() => switchMode('login')}>Sign in</button>
              <button role="tab" aria-selected={mode === 'signup'} className={mode === 'signup' ? 'active' : ''} onClick={() => switchMode('signup')}>Create account</button>
            </div>}

            {portal && !info.comingSoon && !requested && mode === 'login' && <form className="login-form" onSubmit={submit}>
              <label className="field-label" htmlFor="login-email">Login ID</label>
              <div className="input-shell"><EmailOutlined /><input id="login-email" type="email" autoComplete="username" placeholder="name@gjimt.ac.in" value={email} onChange={(e) => { setEmail(e.target.value); setError('') }} required /></div>
              <div className="password-row"><label className="field-label" htmlFor="login-password">Password</label><button type="button" className="forgot-link" onClick={forgot}>Forgot password?</button></div>
              <PasswordInput id="login-password" value={password} onChange={(e) => { setPassword(e.target.value); setError('') }} show={showPassword} onToggle={() => setShowPassword((value) => !value)} placeholder="Enter your password" autoComplete="current-password" />
              <div className="remember-row"><label><input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} /><span>Remember me</span></label></div>
              {error && <div className="form-error" role="alert">{error}</div>}
              <button className="primary-login" disabled={busy} type="submit"><span>{busy ? 'Signing in…' : `Sign in as ${info.label}`}</span><ArrowForwardRounded /></button>
              {isFirebaseConfigured && <>
                <div className="divider"><span>or</span></div>
                <button className="google-login" type="button" onClick={googleLogin} disabled={busy}><GoogleMark /><span>Continue with Google</span></button>
              </>}
              {canSignUp && <p className="switch-auth">New to the Placement Cell? <button type="button" onClick={() => switchMode('signup')}>Create an account</button></p>}
              {!canSignUp && <p className="switch-auth muted">Admin accounts are set up by the college. Forgot the password? Contact the system administrator.</p>}
            </form>}

            {portal && !info.comingSoon && !requested && mode === 'signup' && <form className="login-form signup-form" onSubmit={signUp} noValidate>
              <label className="field-label" htmlFor="signup-name">Full name</label>
              <div className={`input-shell ${show('name') ? 'invalid' : ''}`}><BadgeOutlined /><input id="signup-name" autoComplete="name" placeholder="e.g. Simran Kaur" value={name} onChange={(e) => { setName(e.target.value); setError('') }} aria-invalid={Boolean(show('name')) || undefined} required /></div>
              {show('name') && <span className="field-hint error">{problems.name}</span>}

              <label className="field-label spaced" htmlFor="signup-email">Email</label>
              <div className={`input-shell ${show('email') ? 'invalid' : ''}`}><EmailOutlined /><input id="signup-email" type="email" autoComplete="email" placeholder="you@gjimt.ac.in" value={email} onChange={(e) => { setEmail(e.target.value); setError('') }} aria-invalid={Boolean(show('email')) || undefined} required /></div>
              {show('email') && <span className="field-hint error">{problems.email}</span>}

              <label className="field-label spaced" htmlFor="signup-password">Password</label>
              <PasswordInput id="signup-password" value={password} onChange={(e) => { setPassword(e.target.value); setError('') }} show={showPassword} onToggle={() => setShowPassword((value) => !value)} placeholder="At least 8 characters" autoComplete="new-password" invalid={Boolean(show('password'))} />
              {password && <div className={`strength s${strength.score}`} aria-live="polite"><span className="strength-bars"><i /><i /><i /><i /></span><span>{strength.label} password</span></div>}
              <span className={`field-hint ${show('password') ? 'error' : ''}`}>{show('password') ? problems.password : 'Use 8+ characters with at least one letter and one number.'}</span>

              <label className="field-label spaced" htmlFor="signup-confirm">Confirm password</label>
              <PasswordInput id="signup-confirm" value={confirm} onChange={(e) => { setConfirm(e.target.value); setError('') }} show={showPassword} onToggle={() => setShowPassword((value) => !value)} placeholder="Type it again" autoComplete="new-password" invalid={Boolean(show('confirm'))} />
              {show('confirm') && <span className="field-hint error">{problems.confirm}</span>}
              {!problems.confirm && confirm && !problems.password && <span className="field-hint ok"><CheckCircleRounded /> Passwords match</span>}

              {error && <div className="form-error" role="alert">{error}</div>}
              <button className="primary-login spaced-top" disabled={busy} type="submit"><span>{busy ? 'Sending request…' : 'Create account'}</span><ArrowForwardRounded /></button>
              <p className="switch-auth">Already have an account? <button type="button" onClick={() => switchMode('login')}>Sign in</button></p>
              <p className="secure-note">New accounts can sign in after the Admin approves them.</p>
            </form>}

            <div className="login-bottom-note"><span>© {new Date().getFullYear()} GJIMT Placement Cell</span></div>
          </section>
        </div>
        <LoginRail />
      </div>
    </div>
  )
}

function GoogleMark() {
  return (
    <svg className="google-mark" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
    </svg>
  )
}
