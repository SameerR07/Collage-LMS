import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import {
  GoogleAuthProvider,
  browserLocalPersistence,
  browserSessionPersistence,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  setPersistence,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth'
import { doc, getDoc, setDoc } from 'firebase/firestore'
import { auth, db, isFirebaseConfigured } from '../lib/firebase'
import { friendlyAuthError, signUpProblems } from '../lib/authHelpers'
import { createLocalAccount, findLocalAccount, isBuiltInEmail, verifyAccount } from '../lib/localAccounts'
import { ROLE_INFO, isRole, signInProblem } from '../lib/roles'
import { schedulePublicStatsRefresh } from '../lib/dataStore'

const SESSION_KEY = 'gjimt:lms:session'
const OLD_SESSION_KEY = 'gjimt:lms:demo-session' // before roles — no longer accepted
const AuthContext = createContext(null)

// Signed-in person as the app sees them (local / built-in accounts)
const localSessionUser = (account) => ({
  uid: account.uid,
  displayName: account.name,
  email: account.email,
  photoURL: '',
  providerId: account.builtIn ? 'builtin' : 'local',
  builtIn: Boolean(account.builtIn),
  role: account.role,
  status: account.status,
  createdAt: account.createdAt,
  signedInAt: new Date().toISOString(),
})

// Firebase user + role from users/{uid}
const firebaseSessionUser = (firebaseUser, profile) => ({
  uid: firebaseUser.uid,
  displayName: firebaseUser.displayName || profile?.name || '',
  email: firebaseUser.email,
  photoURL: firebaseUser.photoURL || '',
  emailVerified: firebaseUser.emailVerified,
  providerData: firebaseUser.providerData,
  metadata: firebaseUser.metadata,
  providerId: 'firebase',
  builtIn: false,
  role: profile?.role,
  status: profile?.status,
})

const clearSession = () => {
  ;[SESSION_KEY, OLD_SESSION_KEY].forEach((key) => { localStorage.removeItem(key); sessionStorage.removeItem(key) })
}
const saveSession = (user, remember) => {
  clearSession()
  ;(remember ? localStorage : sessionStorage).setItem(SESSION_KEY, JSON.stringify(user))
}

/** Saved local session — only if the account still exists, is active and has the same role. */
const restoreLocalSession = () => {
  localStorage.removeItem(OLD_SESSION_KEY); sessionStorage.removeItem(OLD_SESSION_KEY)
  try {
    const raw = localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY)
    const saved = raw ? JSON.parse(raw) : null
    if (!saved || !isRole(saved.role)) return null
    if (saved.builtIn) return isBuiltInEmail(saved.email) ? saved : null
    const account = findLocalAccount(saved.email)
    if (!account || account.status !== 'active' || account.role !== saved.role) { clearSession(); return null }
    return saved
  } catch { return null }
}

async function readProfile(uid) {
  const snapshot = await getDoc(doc(db, 'users', uid))
  return snapshot.exists() ? snapshot.data() : null
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => (isFirebaseConfigured ? null : restoreLocalSession()))
  const [loading, setLoading] = useState(isFirebaseConfigured)

  useEffect(() => {
    if (!isFirebaseConfigured) return undefined
    return onAuthStateChanged(auth, async (nextUser) => {
      if (!nextUser) { setUser(null); setLoading(false); return }
      try {
        const profile = await readProfile(nextUser.uid)
        if (signInProblem(profile && { role: profile.role, status: profile.status })) { await signOut(auth); setUser(null) }
        else {
          setUser(firebaseSessionUser(nextUser, profile))
          schedulePublicStatsRefresh(3000) // keep the login-page numbers current for existing data
        }
      } catch {
        await signOut(auth); setUser(null)
      } finally { setLoading(false) }
    })
  }, [])

  /** Sign in through the portal the person chose (admin / placement). */
  const signInEmail = async (email, password, remember = true, chosenRole) => {
    if (!isFirebaseConfigured) {
      const account = await verifyAccount(email, password)
      const problem = signInProblem(account, chosenRole)
      if (problem) throw new Error(problem)
      const sessionUser = localSessionUser(account)
      saveSession(sessionUser, remember)
      setUser(sessionUser)
      return sessionUser
    }
    let result
    try {
      await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence)
      result = await signInWithEmailAndPassword(auth, email.trim(), password)
    } catch (error) {
      throw new Error(friendlyAuthError(error, 'Sign-in failed. Please check your details.'))
    }
    const profile = await readProfile(result.user.uid).catch(() => null)
    const problem = signInProblem(profile ? { role: profile.role, status: profile.status } : { role: 'placement', status: 'pending' }, chosenRole)
    if (problem) { await signOut(auth); throw new Error(problem) }
    const sessionUser = firebaseSessionUser(result.user, profile)
    setUser(sessionUser)
    return sessionUser
  }

  /** New accounts (Placement Cell) are created waiting for the Admin's approval — no sign-in yet. */
  const signUpEmail = async ({ name, email, password, confirm = password, role = 'placement' }) => {
    if (!ROLE_INFO[role]?.signUp) throw new Error('New accounts for this portal are created by the Admin.')
    const problems = signUpProblems({ name, email, password, confirm })
    const firstProblem = Object.values(problems)[0]
    if (firstProblem) throw new Error(firstProblem)
    const cleanName = name.trim().replace(/\s+/g, ' ')

    if (!isFirebaseConfigured) {
      const account = await createLocalAccount({ name: cleanName, email, password, role, status: 'pending' })
      return { account, pending: true, verificationSent: false }
    }

    if (isBuiltInEmail(email)) throw new Error('This email is reserved. Please use a different email.')
    try {
      const result = await createUserWithEmailAndPassword(auth, email.trim(), password)
      await updateProfile(result.user, { displayName: cleanName })
      await setDoc(doc(db, 'users', result.user.uid), { name: cleanName, email: result.user.email, role, status: 'pending', createdAt: new Date().toISOString() })
      let verificationSent = false
      try { await sendEmailVerification(result.user); verificationSent = true } catch { /* can be re-sent later */ }
      await signOut(auth)
      return { account: { name: cleanName, email: result.user.email, role, status: 'pending' }, pending: true, verificationSent }
    } catch (error) {
      throw new Error(friendlyAuthError(error, 'Your account could not be created.'))
    }
  }

  const signInGoogle = async (remember = true, chosenRole) => {
    if (!isFirebaseConfigured) throw new Error('Google sign-in works once Firebase is connected.')
    await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence)
    const provider = new GoogleAuthProvider()
    provider.setCustomParameters({ prompt: 'select_account' })
    let result
    try { result = await signInWithPopup(auth, provider) } catch (error) { throw new Error(friendlyAuthError(error, 'Google sign-in failed.')) }
    let profile = await readProfile(result.user.uid).catch(() => null)
    if (!profile) {
      profile = { name: result.user.displayName || '', email: result.user.email, role: 'placement', status: 'pending', createdAt: new Date().toISOString() }
      await setDoc(doc(db, 'users', result.user.uid), profile).catch(() => {})
    }
    const problem = signInProblem({ role: profile.role, status: profile.status }, chosenRole)
    if (problem) { await signOut(auth); throw new Error(problem) }
    const sessionUser = firebaseSessionUser(result.user, profile)
    setUser(sessionUser)
    return sessionUser
  }

  const resetPassword = async (email) => {
    if (!isFirebaseConfigured) throw new Error('Password reset by email works once Firebase is connected. Ask the Admin for help.')
    try { await sendPasswordResetEmail(auth, email.trim()) } catch (error) { throw new Error(friendlyAuthError(error, 'Password reset could not be sent.')) }
  }

  const logout = async () => {
    clearSession()
    if (isFirebaseConfigured) await signOut(auth)
    setUser(null)
  }

  const value = useMemo(
    () => ({
      user,
      role: user?.role || null,
      loading,
      isFirebaseConfigured,
      signInEmail,
      signUpEmail,
      signInGoogle,
      resetPassword,
      logout,
    }),
    [user, loading],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
