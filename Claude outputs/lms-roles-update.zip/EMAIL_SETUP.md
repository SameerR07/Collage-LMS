# Email setup — placement drive emails

When the Placement Cell saves a drive with **Save & email**, every eligible student gets one personal email with all the drive details. Students are eligible when their course is ticked and they are not left out (by default, Opted Out and Not Eligible students are left out).

The app works before email is set up. Drives are saved, and their emails wait in a queue. Once you've added the settings, open the drive and press **Send waiting emails**.

## 1. Get a password for the sending account

**Gmail or Google Workspace (recommended)**

Your normal Gmail password will not work here. Gmail needs an *App Password*:

1. Sign in to the Gmail account that should send the emails, for example a placement cell Gmail.
2. Open **Google Account → Security** and turn on **2-Step Verification**.
3. On the same page, open **App passwords**. Create one called `GJIMT LMS`.
4. Google shows a 16-letter password, like `abcd efgh ijkl mnop`. Copy it.

**College email server**

Ask your IT team for the SMTP host, the port, and a username and password.

## 2. Put the settings in `server/.env`

1. In the project folder, copy `server/.env.example` to `server/.env`.
2. Fill in these two lines:

```
SMTP_USER=yourplacementcell@gmail.com
SMTP_PASS=abcd efgh ijkl mnop
```

For a non-Gmail server, also set `SMTP_HOST` and `SMTP_PORT`. Use `SMTP_SECURE=false` for port 587.

`server/.env` is private:

- it is in `.gitignore`, so it is never committed;
- it is never sent to the browser;
- don't share it or paste it anywhere public.

## 3. Check it works

```
npm run mail-check
```

You should see `✓ Email works: …`. If you see a message about the password not being accepted, make sure you used the App Password and not the normal password.

## 4. Use it

Start the app as usual:

```
npm run dev
```

The email service runs inside it automatically. If the app was already running, it picks up the new settings by itself.

The Drive page shows **Email ready — sends as pl••••@gmail.com** when everything is set.

## Good to know

- **Gmail sending limits:** about 500 emails a day for a normal Gmail account, and about 2,000 for Google Workspace. Big batches beyond that will show as *Failed*. Use **Retry failed** the next day.
- **Speed:** each student gets their own email, with a short pause between emails. You can change the pause with `MAIL_DELAY_MS`.
- **Hosting the built app:** for example with Firebase Hosting, the email service has to run somewhere too. Run `npm run mail-server` on a server, route `/api/mail` to it, and set `MAIL_API_TOKEN` (and `VITE_MAIL_API_TOKEN` for the app) so only your app can use it.
