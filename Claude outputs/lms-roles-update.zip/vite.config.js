import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { fileURLToPath } from 'node:url'

/* Placement drive emails: serve /api/mail/* from the dev and preview servers,
   so `npm run dev` is all that's needed. Settings live in server/.env. */
function mailApi() {
  let api
  const mount = async (server) => {
    try {
      // Loaded at run time (not bundled into this config), so a missing package can't stop the dev server.
      const moduleUrl = new URL('./server/mailApi.mjs', import.meta.url).href
      const { createMailApi } = await import(/* @vite-ignore */ moduleUrl)
      api = createMailApi({ envFile: fileURLToPath(new URL('./server/.env', import.meta.url)) })
      server.middlewares.use((req, res, next) => api.handle(req, res, next))
    } catch (error) {
      // e.g. "npm install" not run yet after updating — the app still works, emails just wait in the queue
      server.config.logger.warn(`\n  Email service is off: ${error.message}\n  Run "npm install" once, then restart "npm run dev".\n`)
    }
  }
  return {
    name: 'gjimt-mail-api',
    configureServer: mount,
    configurePreviewServer: mount,
    buildEnd() { api?.close() },
  }
}

export default defineConfig({
  plugins: [react(), mailApi()],
})
